from ultralytics import YOLO

model = YOLO('yolov8n-cls.pt') 

model.train(data='C:\\Users\\DIGRA\\AppData\\Local\\Programs\\Python\\Python39\\Lib\\site-packages\\DiveTrainer\\Dataset\\ucf_sports_actions\\ucf action\\Diving-Side\\data',epochs=30, imgsz=64)

