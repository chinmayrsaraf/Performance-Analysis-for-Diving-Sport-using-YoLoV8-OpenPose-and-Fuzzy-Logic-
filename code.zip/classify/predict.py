from ultralytics import YOLO
model = YOLO('C:\\Users\\DIGRA\\AppData\\Local\\Programs\\Python\\Python39\\Lib\\site-packages\\DiveTrainer\\Classification\\runs\\classify\\train5\\weights\\last.pt')
results = model('C:\\Users\\DIGRA\\AppData\\Local\\Programs\\Python\\Python39\\Lib\\site-packages\\DiveTrainer\\Dataset\\ucf_sports_actions\\ucf action\\Diving-Side\\005\\4475-1_70560.jpg')
names_dict = results[0].names
probs = results[0].probs.tolist()
print(names_dict)
print(probs)
