#!/usr/bin/env python
# -*- coding: utf-8 -*-

## INIT
import toml
import os
import time
import cv2
from pathlib import Path
import logging, logging.handlers

def read_config_file(config):
    config_dict = toml.load(config)
    return config_dict

def base_params(config_dict):
    video_dir = Path(config_dict.get('project').get('video_dir')).resolve()
    if video_dir == '': video_dir = os.getcwd()
    video_file = Path(config_dict.get('project').get('video_file'))
    result_dir = Path(config_dict.get('project').get('result_dir')).resolve()
    if result_dir == '': result_dir = os.getcwd()
    
    video = cv2.VideoCapture(str(video_dir / video_file))
    frame_rate = video.get(cv2.CAP_PROP_FPS)
    try:
        1/frame_rate
    except ZeroDivisionError:
        print('Invalid Path')
        raise
    video.release()

    return video_dir, video_file, result_dir, frame_rate


def detect_pose(config='Config_demo.toml'):
    from DiveTrainer.detect_pose import detect_pose_fun
    
    config_dict = read_config_file(config)
    _, video_file, result_dir, _ = base_params(config_dict)
        
    with open(result_dir / 'logs.txt', 'a+') as log_f: pass
    logging.basicConfig(format='%(message)s', level=logging.INFO, force=True, 
        handlers = [logging.handlers.TimedRotatingFileHandler(result_dir / 'logs.txt', when='D', interval=7), logging.StreamHandler()]) 
    
    logging.info("\n\n---------------------------------------------------------------------")
    logging.info(f"Detect pose for video {video_file}")
    logging.info("---------------------------------------------------------------------")
    start = time.time()
    
    detect_pose_fun(config_dict)
    
    end = time.time()
    logging.info(f'Pose detection took {end-start:.2f} s.')
    
    
def compute_angles(config='Config_demo.toml'):
    from DiveTrainer.compute_angles import compute_angles_fun

    config_dict = read_config_file(config)
    _, video_file, result_dir, _ = base_params(config_dict)
        
    with open(result_dir / 'logs.txt', 'a+') as log_f: pass
    logging.basicConfig(format='%(message)s', level=logging.INFO, force=True, 
        handlers = [logging.handlers.TimedRotatingFileHandler(result_dir / 'logs.txt', when='D', interval=7), logging.StreamHandler()])
        
    joint_angles = config_dict.get('compute_angles').get('joint_angles')
    segment_angles = config_dict.get('compute_angles').get('segment_angles')

    logging.info("\n\n---------------------------------------------------------------------")
    logging.info(f"Compute angles for video {video_file} ")
    logging.info(f"for {joint_angles}")
    logging.info(f"and {segment_angles}.")
    logging.info("---------------------------------------------------------------------")
    start = time.time()
    
    compute_angles_fun(config_dict)
    
    end = time.time()
    logging.info(f'Joint and segment computation took {end-start:.2f} s.')
    
    

